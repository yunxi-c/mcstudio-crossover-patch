from pathlib import Path
import shutil

base = Path(__file__).resolve().parent
driver = base / 'vendor-source/wine/dlls/winemac.drv'
for backup in driver.glob('*.modpc-original'):
    shutil.copy2(backup, backup.with_name(backup.name.removesuffix('.modpc-original')))

def patch(name, old, new):
    p = driver / name
    backup = p.with_name(p.name + '.modpc-original')
    if not backup.exists():
        shutil.copy2(p, backup)
    text = p.read_text()
    if new in text:
        return
    assert text.count(old) == 1, (name, old[:100], text.count(old))
    p.write_text(text.replace(old, new))

shutil.copy2(base/'cocoa_shared_gl.m', driver/'cocoa_shared_gl.m')
patch('Makefile.in', '\t-framework Metal \\\n', '\t-framework IOSurface \\\n\t-framework Metal \\\n')
patch('Makefile.in', '\tcocoa_status_item.m \\\n', '\tcocoa_shared_gl.m \\\n\tcocoa_status_item.m \\\n')
patch('macdrv.h', '    WM_MACDRV_ACTIVATE_ON_FOLLOWING_FOCUS,',
      '    WM_MACDRV_ACTIVATE_ON_FOLLOWING_FOCUS,\n    WM_MACDRV_SHARED_GL_PRESENT,')
patch('macdrv.h', '    macdrv_metal_view     metal_view;\n};',
      '    macdrv_metal_view     metal_view;\n    BOOL shared_gl;\n    HWND shared_root;\n};')
patch('macdrv_cocoa.h', 'extern void macdrv_flush_opengl_context(macdrv_opengl_context c);',
      '''extern void macdrv_flush_opengl_context(macdrv_opengl_context c);
extern void macdrv_shared_gl_attach(macdrv_view v, CGRect rect);
extern void macdrv_shared_gl_detach(macdrv_view v);
extern unsigned int macdrv_shared_gl_copy(void *cgl, unsigned int width, unsigned int height);
extern void macdrv_shared_gl_present(macdrv_window w, macdrv_view parent, uintptr_t child,
                                    unsigned int surface_id, CGRect rect);''')
patch('window.c', '    if (surface->metal_view) macdrv_view_release_metal_view(surface->metal_view);',
      '''    if (surface->shared_gl)
    {
        NtUserPostMessage(surface->shared_root, WM_MACDRV_SHARED_GL_PRESENT,
                          (WPARAM)client->hwnd, 0);
        macdrv_shared_gl_detach(surface->cocoa_view);
    }
    if (surface->metal_view) macdrv_view_release_metal_view(surface->metal_view);''')
patch('window.c', '    if (!(data = get_win_data(toplevel))) return;\n    OffsetRect(&rect,',
      '''    if (!(data = get_win_data(toplevel)))
    {
        if (getenv("MODPC_SHARED_GL") && !strcmp(getenv("MODPC_SHARED_GL"),"1"))
        {
            surface->shared_gl = TRUE;
            surface->shared_root = toplevel;
            macdrv_shared_gl_attach(surface->cocoa_view, cgrect_from_rect(rect));
            TRACE("shared GL child %p hosted by foreign root %p\\n", hwnd, toplevel);
        }
        return;
    }
    OffsetRect(&rect,''')
patch('window.c', '    switch(msg)\n    {\n    case WM_MACDRV_SET_WIN_REGION:',
      '''    switch(msg)
    {
    case WM_MACDRV_SHARED_GL_PRESENT:
        if ((data = get_win_data(hwnd)))
        {
            RECT rect = {0};
            HWND child = (HWND)wp;
            macdrv_window window = data->cocoa_window;
            int x = data->rects.client.left - data->rects.visible.left;
            int y = data->rects.client.top - data->rects.visible.top;
            release_win_data(data);
            if (window)
            {
                if (lp)
                {
                    NtUserGetClientRect(child, &rect, NtUserGetWinMonitorDpi(child, MDT_RAW_DPI));
                    NtUserMapWindowPoints(child, hwnd, (POINT *)&rect, 2, NtUserGetWinMonitorDpi(hwnd, MDT_RAW_DPI));
                    OffsetRect(&rect, x, y);
                }
                macdrv_shared_gl_present(window, NULL, (uintptr_t)child, lp, cgrect_from_rect(rect));
            }
        }
        return 0;
    case WM_MACDRV_SET_WIN_REGION:''')
patch('opengl.c', '    macdrv_flush_opengl_context(context->context);\n    return TRUE;',
      '''    if (base->client)
    {
        struct macdrv_client_surface *client = impl_from_client_surface(base->client);
        if (client->shared_gl)
        {
            GLint size[2] = {0};
            unsigned int surface_id;
            CGLGetParameter(context->cglcontext, kCGLCPSurfaceBackingSize, size);
            surface_id = macdrv_shared_gl_copy(context->cglcontext, size[0], size[1]);
            if (surface_id) NtUserPostMessage(client->shared_root, WM_MACDRV_SHARED_GL_PRESENT,
                                              (WPARAM)base->client->hwnd, surface_id);
        }
    }
    macdrv_flush_opengl_context(context->context);
    return TRUE;''')
patch('opengl.c', '    int major = 1, minor = 0, profile = WGL_CONTEXT_CORE_PROFILE_BIT_ARB, flags = 0;',
      '    int major = 3, minor = 2, profile = WGL_CONTEXT_CORE_PROFILE_BIT_ARB, flags = WGL_CONTEXT_FORWARD_COMPATIBLE_BIT_ARB;')
patch('opengl.c', '    if ((major == 3 && (minor == 2 || minor == 3)) ||',
      '    if (major >= 3) flags |= WGL_CONTEXT_FORWARD_COMPATIBLE_BIT_ARB;\n    if ((major == 3 && (minor == 2 || minor == 3)) ||')
print('Experimental shared-OpenGL driver source patched; installed binaries untouched.')

patch('cocoa_event.m', 'void OnMainThread(dispatch_block_t block)\n{\n@autoreleasepool\n{',
      'void OnMainThread(dispatch_block_t block)\n{\n@autoreleasepool\n{\n    if ([NSThread isMainThread]) { block(); return; }')
