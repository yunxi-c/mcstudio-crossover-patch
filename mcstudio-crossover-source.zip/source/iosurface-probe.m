#define GL_SILENCE_DEPRECATION
#import <Cocoa/Cocoa.h>
#import <OpenGL/gl3.h>
#import <OpenGL/CGLIOSurface.h>
#import <IOSurface/IOSurface.h>
#include <sys/wait.h>

int main(int argc, char **argv)
{
    @autoreleasepool {
        if (argc == 3 && !strcmp(argv[1],"--lookup"))
        {
            IOSurfaceRef other = IOSurfaceLookup((IOSurfaceID)strtoul(argv[2],NULL,10));
            if (!other) return 5;
            IOSurfaceLock(other,kIOSurfaceLockReadOnly,NULL);
            unsigned char *p = IOSurfaceGetBaseAddress(other);
            BOOL valid = abs(p[0]-191)<3 && abs(p[1]-128)<3 && abs(p[2]-64)<3;
            printf("Separate process received BGRA: %u %u %u %u\n",p[0],p[1],p[2],p[3]);
            IOSurfaceUnlock(other,kIOSurfaceLockReadOnly,NULL);
            CFRelease(other);
            return valid ? 0 : 6;
        }
        unsigned int width = argc == 3 ? atoi(argv[1]) : 525;
        unsigned int height = argc == 3 ? atoi(argv[2]) : 350;
        size_t pitch = IOSurfaceAlignProperty(kIOSurfaceBytesPerRow,width*4);
        [NSApplication sharedApplication];
        [NSApp setActivationPolicy:NSApplicationActivationPolicyProhibited];
        NSOpenGLPixelFormatAttribute attrs[] = {
            NSOpenGLPFAOpenGLProfile, NSOpenGLProfileVersion4_1Core,
            NSOpenGLPFAAccelerated, NSOpenGLPFADoubleBuffer,
            NSOpenGLPFAColorSize, 24, NSOpenGLPFAAlphaSize, 8, 0
        };
        NSOpenGLPixelFormat *pf = [[NSOpenGLPixelFormat alloc] initWithAttributes:attrs];
        NSOpenGLContext *ctx = [[NSOpenGLContext alloc] initWithFormat:pf shareContext:nil];
        if (!ctx) { fprintf(stderr, "Cannot create accelerated OpenGL context\n"); return 1; }
        NSWindow *window = [[NSWindow alloc] initWithContentRect:NSMakeRect(-10000,-10000,width,height)
            styleMask:NSWindowStyleMaskBorderless backing:NSBackingStoreBuffered defer:NO];
        [window setAlphaValue:0];
        [window setCollectionBehavior:NSWindowCollectionBehaviorStationary];
        NSView *view = [[NSView alloc] initWithFrame:NSMakeRect(0,0,width,height)];
        [window setContentView:view];
        [window orderFront:nil];
        [ctx setView:view];
        [ctx makeCurrentContext];
        [ctx update];
        printf("Renderer: %s; version: %s\n",glGetString(GL_RENDERER),glGetString(GL_VERSION));
        NSDictionary *props = @{
            (id)kIOSurfaceWidth:@(width), (id)kIOSurfaceHeight:@(height),
            (id)kIOSurfaceBytesPerElement:@4, (id)kIOSurfaceBytesPerRow:@(pitch),
            (id)kIOSurfaceAllocSize:@(IOSurfaceAlignProperty(kIOSurfaceAllocSize,pitch*height)), (id)kIOSurfacePixelFormat:@(0x42475241),
            (id)kIOSurfaceIsGlobal:@YES
        };
        IOSurfaceRef surface = IOSurfaceCreate((CFDictionaryRef)props);
        GLuint texture, fbo;
        glGenTextures(1,&texture);
        glBindTexture(GL_TEXTURE_RECTANGLE,texture);
        CGLError e = CGLTexImageIOSurface2D([ctx CGLContextObj],GL_TEXTURE_RECTANGLE,GL_RGBA8,
            width,height,GL_BGRA,GL_UNSIGNED_INT_8_8_8_8_REV,surface,0);
        if(e) { fprintf(stderr,"IOSurface binding: %d\n",e);return 2; }
        glGenFramebuffers(1,&fbo);
        glBindFramebuffer(GL_FRAMEBUFFER,fbo);
        glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_RECTANGLE,texture,0);
        if(glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE)return 3;
        glBindFramebuffer(GL_FRAMEBUFFER,0);
        glViewport(0,0,width,height);
        glClearColor(0.25,0.5,0.75,0);
        glClear(GL_COLOR_BUFFER_BIT);
        glBindFramebuffer(GL_READ_FRAMEBUFFER,0);
        glBindFramebuffer(GL_DRAW_FRAMEBUFFER,fbo);
        glBlitFramebuffer(0,0,width,height,0,0,width,height,GL_COLOR_BUFFER_BIT,GL_NEAREST);
        glColorMask(GL_FALSE,GL_FALSE,GL_FALSE,GL_TRUE);
        glClearColor(0,0,0,1);
        glClear(GL_COLOR_BUFFER_BIT);
        glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);
        glFinish();
        GLenum error = glGetError();
        printf("GPU framebuffer transfer error: 0x%x; IOSurface ID: %u\n",error,IOSurfaceGetID(surface));
        IOSurfaceLock(surface,kIOSurfaceLockReadOnly,NULL);
        unsigned char *pixel=IOSurfaceGetBaseAddress(surface);
        printf("Validation pixel BGRA: %u %u %u %u\n",pixel[0],pixel[1],pixel[2],pixel[3]);
        BOOL valid=abs(pixel[0]-191)<3 && abs(pixel[1]-128)<3 && abs(pixel[2]-64)<3;
        IOSurfaceUnlock(surface,kIOSurfaceLockReadOnly,NULL);
        char id_text[32];
        snprintf(id_text,sizeof(id_text),"%u",IOSurfaceGetID(surface));
        fflush(stdout);
        pid_t child = fork();
        if (!child) { execl(argv[0],argv[0],"--lookup",id_text,NULL); _exit(7); }
        int status = 0;
        waitpid(child,&status,0);
        BOOL shared = WIFEXITED(status) && !WEXITSTATUS(status);
        [window orderOut:nil];
        CFRelease(surface);
        return error || !valid || !shared ? 4 : 0;
    }
}
