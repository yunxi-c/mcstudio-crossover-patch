/* Experimental GPU OpenGL bridge for foreign-process child windows.
 * Only used when MODPC_SHARED_GL=1; no software renderer or screen capture.
 */
#define GL_SILENCE_DEPRECATION
#include "config.h"
#import "cocoa_app.h"
#import "cocoa_event.h"
#import "cocoa_window.h"
#import <OpenGL/gl3.h>
#import <OpenGL/CGLIOSurface.h>
#import <IOSurface/IOSurface.h>
#import <objc/runtime.h>
#include <pthread.h>

@interface WineWindow (ModPCFactory)
+ (WineWindow *)createWindowWithFeatures:(const struct macdrv_window_features *)features
                              windowFrame:(NSRect)frame hwnd:(void *)hwnd queue:(WineEventQueue *)queue;
@end

@interface ModPCOffscreenWindow : WineWindow
- (void)updateForGLSubviews;
- (void)windowDidDrawContent;
- (void)setCommandDone:(BOOL)value;
@end
@implementation ModPCOffscreenWindow
- (void)updateForGLSubviews {}
- (void)windowDidDrawContent {}
- (void)setCommandDone:(BOOL)value {}
@end

@interface ModPCSharedView : NSView
@end
@implementation ModPCSharedView
- (BOOL)isFlipped { return YES; }
- (BOOL)wantsUpdateLayer { return YES; }
- (void)updateLayer {}
@end

static NSMutableDictionary *offscreen_windows;
static char host_views_key;

void macdrv_shared_gl_attach(macdrv_view v, CGRect rect)
{
    OnMainThread(^{
        NSView *view = (NSView *)v;
        NSValue *key = [NSValue valueWithPointer:view];
        if (!offscreen_windows) offscreen_windows = [[NSMutableDictionary alloc] init];
        ModPCOffscreenWindow *window = [offscreen_windows objectForKey:key];
        if (!window)
        {
            struct macdrv_window_features features = {0};
            features.prevents_app_activation = true;
            window = (ModPCOffscreenWindow *)[ModPCOffscreenWindow createWindowWithFeatures:&features
                windowFrame:NSMakeRect(-10000,-10000,MAX(1,rect.size.width),MAX(1,rect.size.height))
                hwnd:NULL queue:nil];
            if (!window) return;
            [window setReleasedWhenClosed:NO];
            [window setAlphaValue:0];
            [window setIgnoresMouseEvents:YES];
            [window setExcludedFromWindowsMenu:YES];
            [window setContentView:view];
            [window orderFront:nil];
            [offscreen_windows setObject:window forKey:key];
            [NSApp setActivationPolicy:NSApplicationActivationPolicyAccessory];
            fprintf(stderr,"modpc-shared-gl: offscreen drawable created %.0fx%.0f\n",rect.size.width,rect.size.height);
        }
        [window setContentSize:NSMakeSize(MAX(1,rect.size.width),MAX(1,rect.size.height))];
        [view setFrame:NSMakeRect(0,0,MAX(1,rect.size.width),MAX(1,rect.size.height))];
        [view setHidden:NO];
    });
}

void macdrv_shared_gl_detach(macdrv_view v)
{
    OnMainThread(^{
        NSValue *key = [NSValue valueWithPointer:v];
        NSWindow *window = [offscreen_windows objectForKey:key];
        [window orderOut:nil];
        [window setContentView:nil];
        [offscreen_windows removeObjectForKey:key];
    });
}

struct shared_gl_frame
{
    CGLContextObj context;
    IOSurfaceRef surface;
    GLuint texture, fbo;
    unsigned int width, height;
    struct shared_gl_frame *next;
};
static struct shared_gl_frame *frames;
static pthread_mutex_t frames_lock = PTHREAD_MUTEX_INITIALIZER;

unsigned int macdrv_shared_gl_copy(void *cgl, unsigned int width, unsigned int height)
{
    struct shared_gl_frame *f;
    GLint read_fbo, draw_fbo, read_buffer, rectangle_texture;
    GLboolean color_mask[4];
    GLfloat clear_color[4];
    GLboolean scissor, srgb;
    unsigned int surface_id = 0;
    if (!width || !height || width > 16384 || height > 16384) return 0;
    pthread_mutex_lock(&frames_lock);
    for (f = frames; f && f->context != cgl; f = f->next) {}
    if (!f)
    {
        f = calloc(1,sizeof(*f));
        if (!f) goto done;
        f->context = cgl; f->next = frames; frames = f;
    }
    glGetIntegerv(GL_READ_FRAMEBUFFER_BINDING,&read_fbo);
    glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&draw_fbo);
    glGetIntegerv(GL_READ_BUFFER,&read_buffer);
    glGetIntegerv(GL_TEXTURE_BINDING_RECTANGLE,&rectangle_texture);
    scissor = glIsEnabled(GL_SCISSOR_TEST);
    srgb = glIsEnabled(GL_FRAMEBUFFER_SRGB);
    if (f->width != width || f->height != height)
    {
        if (f->fbo) glDeleteFramebuffers(1,&f->fbo);
        if (f->texture) glDeleteTextures(1,&f->texture);
        if (f->surface) CFRelease(f->surface);
        f->fbo = f->texture = 0;
        f->surface = IOSurfaceCreate((CFDictionaryRef)@{
            (id)kIOSurfaceWidth:@(width), (id)kIOSurfaceHeight:@(height),
            (id)kIOSurfaceBytesPerElement:@4,
            (id)kIOSurfaceBytesPerRow:@(IOSurfaceAlignProperty(kIOSurfaceBytesPerRow,(size_t)width*4)),
            (id)kIOSurfaceAllocSize:@(IOSurfaceAlignProperty(kIOSurfaceAllocSize,IOSurfaceAlignProperty(kIOSurfaceBytesPerRow,(size_t)width*4)*height)),
            (id)kIOSurfacePixelFormat:@(0x42475241), (id)kIOSurfaceIsGlobal:@YES
        });
        if (!f->surface) goto restore;
        glGenTextures(1,&f->texture);
        glBindTexture(GL_TEXTURE_RECTANGLE,f->texture);
        if (CGLTexImageIOSurface2D(cgl,GL_TEXTURE_RECTANGLE,GL_RGBA8,width,height,
            GL_BGRA,GL_UNSIGNED_INT_8_8_8_8_REV,f->surface,0)) goto restore;
        glGenFramebuffers(1,&f->fbo);
        glBindFramebuffer(GL_DRAW_FRAMEBUFFER,f->fbo);
        glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_RECTANGLE,f->texture,0);
        if (glCheckFramebufferStatus(GL_DRAW_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE) goto restore;
        f->width = width; f->height = height;
        fprintf(stderr,"modpc-shared-gl: GPU surface ready %ux%u id=%u\n",width,height,IOSurfaceGetID(f->surface));
    }
    glDisable(GL_SCISSOR_TEST);
    glDisable(GL_FRAMEBUFFER_SRGB);
    glBindFramebuffer(GL_READ_FRAMEBUFFER,0);
    glReadBuffer(GL_BACK);
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER,f->fbo);
    glDrawBuffer(GL_COLOR_ATTACHMENT0);
    /* Flip vertically so the hosted view uses the editor's top-left coordinates. */
    glBlitFramebuffer(0,0,width,height,0,height,width,0,GL_COLOR_BUFFER_BIT,GL_NEAREST);
    /* The game drawable is opaque; its unused alpha must not hide the hosted image. */
    glGetBooleanv(GL_COLOR_WRITEMASK,color_mask);
    glGetFloatv(GL_COLOR_CLEAR_VALUE,clear_color);
    glColorMask(GL_FALSE,GL_FALSE,GL_FALSE,GL_TRUE);
    glClearColor(0,0,0,1);
    glClear(GL_COLOR_BUFFER_BIT);
    glColorMask(color_mask[0],color_mask[1],color_mask[2],color_mask[3]);
    glClearColor(clear_color[0],clear_color[1],clear_color[2],clear_color[3]);
    glFinish();
    surface_id = IOSurfaceGetID(f->surface);
restore:
    glBindTexture(GL_TEXTURE_RECTANGLE,rectangle_texture);
    glBindFramebuffer(GL_READ_FRAMEBUFFER,read_fbo);
    glReadBuffer(read_buffer);
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER,draw_fbo);
    if (scissor) glEnable(GL_SCISSOR_TEST);
    if (srgb) glEnable(GL_FRAMEBUFFER_SRGB);
done:
    pthread_mutex_unlock(&frames_lock);
    return surface_id;
}

void macdrv_shared_gl_present(macdrv_window w, macdrv_view parent, uintptr_t child,
                              unsigned int surface_id, CGRect rect)
{
    /* This runs in the editor process, where its Cocoa window really exists. */
    OnMainThread(^{
        NSWindow *window = (NSWindow *)w;
        NSMutableDictionary *views = objc_getAssociatedObject(window,&host_views_key);
        if (!views)
        {
            views = [NSMutableDictionary dictionary];
            objc_setAssociatedObject(window,&host_views_key,views,OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }
        NSNumber *key = @(child);
        NSView *view = [views objectForKey:key];
        if (!surface_id)
        {
            [view removeFromSuperview];
            [views removeObjectForKey:key];
            return;
        }
        IOSurfaceRef surface = IOSurfaceLookup(surface_id);
        if (!surface) return;
        if (!view)
        {
            view = [[ModPCSharedView alloc] initWithFrame:NSRectFromCGRect(cgrect_mac_from_win(rect))];
            [view setWantsLayer:YES];
            [views setObject:view forKey:key];
            [view release];
            fprintf(stderr,"modpc-shared-gl: editor host created child=%lu id=%u\n",(unsigned long)child,surface_id);
        }
        [view setFrame:NSRectFromCGRect(cgrect_mac_from_win(rect))];
        NSView *root = [window contentView];
        if ([view superview] != root)
        {
            [root addSubview:view positioned:NSWindowAbove relativeTo:nil];
            fprintf(stderr,"modpc-shared-gl: attached to visible root hidden=%d frame=%.0f,%.0f %.0fx%.0f\n",[root isHidden],rect.origin.x,rect.origin.y,rect.size.width,rect.size.height);
        }
        [CATransaction begin];
        [CATransaction setDisableActions:YES];
        [view layer].contents = nil;
        [view layer].contents = (id)surface;
        [view layer].opaque = YES;
        [view layer].contentsGravity = kCAGravityResize;
        [view layer].contentsScale = [window backingScaleFactor];
        [view setHidden:NO];
        [CATransaction commit];
        CFRelease(surface);
    });
}
