# 本次构建参数

先取得 README 指定的 CrossOver 26.3 官方源码，放到 vendor-source/wine，应用 patch-driver.py。使用可产生 x86_64 Windows PE 的 llvm-mingw 与本地 Bison。构建目录与 vendor-source 同级：

```sh
mkdir wine-build
cd wine-build
CC='/usr/bin/clang -arch x86_64' CXX='/usr/bin/clang++ -arch x86_64' ../vendor-source/wine/configure --host=x86_64-apple-darwin --enable-win64 --with-mingw --disable-tests --without-x --without-wayland --without-gnutls --without-freetype --without-gstreamer --without-alsa --without-pulse --without-dbus --without-v4l2
make -j8 dlls/winemac.drv/winemac.so
codesign --force --sign - dlls/winemac.drv/winemac.so
codesign --verify --strict dlls/winemac.drv/winemac.so
```

本次配置没有 Vulkan 开发库，源码依赖 win32u/vulkan.c，因此构建目录 include/config.h 额外定义 SONAME_LIBVULKAN 为 "libMoltenVK.dylib"；这是编译依赖，本方案的游戏渲染仍使用 OpenGL。PATH 需要包含 Bison 与 llvm-mingw 的 bin 目录。

重新构建驱动后必须重新生成 payload/checksums.json，不能沿用旧校验。修改源码也要更新校验。
