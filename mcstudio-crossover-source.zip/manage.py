#!/usr/bin/env python3
"""Install, launch or restore the experimental OpenGL embedding driver."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import uuid

PACKAGE = Path(__file__).resolve().parent
SUPPORT = Path.home() / 'Library/Application Support'
DEFAULT_CROSSOVER = Path('/Applications/CrossOver.app/Contents/SharedSupport/CrossOver')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def setting(text, section, key, value):
    heading = '[' + section + ']'
    match = re.search(r'^' + re.escape(heading) + r'\s*$', text, re.M)
    line = '"' + key + '" = "' + value + '"\n'
    if not match:
        return text.rstrip() + '\n\n' + heading + '\n' + line
    end = re.search(r'^\[', text[match.end():], re.M)
    stop = match.end() + end.start() if end else len(text)
    body = text[match.end():stop]
    pattern = r'^"' + re.escape(key) + r'"\s*=.*$'
    body = re.sub(pattern, lambda _: line.rstrip(), body, flags=re.M) if re.search(pattern, body, re.M) else body.rstrip() + '\n' + line
    return text[:match.end()] + body + '\n' + text[stop:]


def managed_settings(runtime):
    return [('Wine','LibPath',str(runtime/'lib')), ('Wine','BinPath',str(runtime/'bin'))] + [
        ('EnvironmentVariables',k,v) for k,v in {
            'MODPC_SHARED_GL':'1','CX_GRAPHICS_BACKEND':'wined3d','CX_FWD_COMPAT_GL_CTX':'1',
            'LANG':'zh_CN.UTF-8','LC_ALL':'zh_CN.UTF-8','PYTHONIOENCODING':'utf-8'}.items()]


def section_value(text, section, key):
    match = re.search(r'^\['+re.escape(section)+r'\]\s*$', text, re.M)
    if not match: return None
    end = re.search(r'^\[',text[match.end():],re.M)
    stop = match.end()+end.start() if end else len(text)
    found = re.search(r'^"'+re.escape(key)+r'"\s*=\s*"(.*?)"\s*$',text[match.end():stop],re.M)
    return found[1] if found else None


def restored_config(current, original, runtime):
    for section,key,expected in managed_settings(runtime):
        if section_value(current,section,key) != expected:
            raise ValueError('补丁相关设置发生变化，未覆盖：'+section+'/'+key)
    for section,key,_ in managed_settings(runtime):
        previous = section_value(original,section,key)
        if previous is not None:
            current = setting(current,section,key,previous)
        else:
            match = re.search(r'^\['+re.escape(section)+r'\]\s*$',current,re.M)
            if match:
                end = re.search(r'^\[',current[match.end():],re.M)
                stop = match.end()+end.start() if end else len(current)
                body = re.sub(r'^"'+re.escape(key)+r'"\s*=.*\n?', '',current[match.end():stop],flags=re.M)
                current = current[:match.end()]+body+current[stop:]
    return current


def remove_setting(text, section, key):
    match = re.search(r'^\['+re.escape(section)+r'\]\s*$', text, re.M)
    if not match: return text
    end = re.search(r'^\[', text[match.end():], re.M)
    stop = match.end()+end.start() if end else len(text)
    body = re.sub(r'^"'+re.escape(key)+r'"\s*=.*\n?', '', text[match.end():stop], flags=re.M)
    return text[:match.end()]+body+text[stop:]


def launcher_menu_command(bottle, runtime):
    # Detach the real launcher so CrossOver's menu helper exits after opening it.
    command = shlex.join(['/usr/bin/nohup', str(runtime/'bin/wine'), '--bottle', bottle.name,
        '--workdir', str(bottle/'drive_c/Program Files (x86)/Netease/MCStudio'),
        '--debugmsg', '-all', '--cx-app', 'C:/Program Files (x86)/Netease/MCStudio/MCStudio.exe'])
    log = shlex.quote(str(bottle/'modpc-opengl/launcher-icon.log'))
    return command + ' >> ' + log + ' 2>&1 < /dev/null &'


def menu_plan(bottle, runtime, state):
    path = bottle/'cxmenu.conf'
    if not path.is_file() or not (bottle/'drive_c/Program Files (x86)/Netease/MCStudio/MCStudio.exe').is_file():
        return None
    current = path.read_text()
    previous = state.get('menu')
    original = restored_menu(current, Path(previous['backup']).read_text(), previous) if previous else current
    sections = list(previous['sections']) if previous else []
    command = launcher_menu_command(bottle, runtime)
    for section in re.findall(r'^\[(.*?)\]\s*$', current, re.M):
        if not section.endswith('/我的世界开发者启动器.lnk'): continue
        if section not in sections:
            if (section_value(current, section, 'Type') or '').lower() != 'windows':
                raise ValueError('启动器菜单已被自定义，未覆盖：'+section)
            sections.append(section)
    if not sections: return None
    changed = current
    for section in sections:
        changed = setting(changed, section, 'Type', 'raw')
        changed = setting(changed, section, 'Command', command)
    return {'path':str(path), 'sections':sections, 'command':command}, original, changed


def restored_menu(current, original, item):
    for section in item['sections']:
        if section_value(current, section, 'Type') != 'raw' or section_value(current, section, 'Command') != item['command']:
            raise ValueError('补丁相关启动器菜单发生变化，未覆盖：'+section)
        for key in ('Type', 'Command'):
            old = section_value(original, section, key)
            current = setting(current, section, key, old) if old is not None else remove_setting(current, section, key)
    return current


def commit_menu(plan, state, backup):
    if plan is None: return
    item, original, changed = plan
    saved = Path(state['menu']['backup']) if 'menu' in state else backup/'menu'
    item['backup'] = str(saved)
    temp = backup/'menu-original.tmp'
    temp.write_text(original)
    atomic_copy(temp, saved)
    state['menu'] = item
    temp.write_text(changed)
    atomic_copy(temp, Path(item['path']))
    temp.unlink()
    item['installed_sha256'] = digest(Path(item['path']))
    state['menu'] = item


def atomic_copy(source, target):
    temp = target.with_name(target.name + '.' + uuid.uuid4().hex + '.tmp')
    shutil.copy2(source, temp)
    os.replace(temp, target)


def ensure_closed(bottle, runtime):
    # Inspect open files, never terminate a user's editor automatically.
    for path in (bottle / 'drive_c/MCStudioDownload/MCX64Editor/MC_Editor.exe',
                 bottle / 'drive_c/MCStudioDownload/MCX64Editor/Game/Minecraft.Windows.Editor.exe',
                 bottle / 'drive_c/Program Files (x86)/Netease/MCStudio/MCStudio.exe',
                 runtime / 'lib/wine/x86_64-unix/winemac.so'):
        result = subprocess.run(['/usr/sbin/lsof', '-t', str(path)], capture_output=True, text=True)
        if result.returncode == 0 and result.stdout.strip():
            raise ValueError('请先保存并关闭选定编辑器、游戏和选定启动器，然后退出该选定容器的其他程序。')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['install', 'rollback', 'launch', 'status'])
    parser.add_argument('--dry-run', action='store_true')
    parser.add_argument('--bottle', help='需要修改的已有容器名称；省略时显示列表供选择')
    parser.add_argument('--runtime-source', type=Path, default=DEFAULT_CROSSOVER)
    args = parser.parse_args()
    if sys.platform != 'darwin':
        raise ValueError('此包用于 macOS 上的 CrossOver。')
    bottle_root = SUPPORT / 'CrossOver/Bottles'
    name = args.bottle
    if name is None:
        choices = sorted(p.name for p in bottle_root.iterdir() if (p / 'cxbottle.conf').is_file())
        if not choices:
            raise ValueError('没有找到已创建的 CrossOver 容器。')
        print('选择需要操作的容器：')
        for i, item in enumerate(choices, 1): print(str(i) + '. ' + item)
        answer = input('输入编号：').strip()
        if not answer.isdigit() or not 1 <= int(answer) <= len(choices):
            raise ValueError('未选择有效容器，未修改。')
        name = choices[int(answer)-1]
    if not name or name in ('.', '..') or '/' in name or '\\' in name:
        raise ValueError('容器名称无效。')
    bottle = bottle_root / name
    base = bottle / 'modpc-opengl'
    runtime = base / 'runtime'
    driver = runtime / 'lib/wine/x86_64-unix/winemac.so'
    conf = bottle / 'cxbottle.conf'
    state_path = base / 'embed-script-install.json'
    checksums = json.loads((PACKAGE / 'payload/checksums.json').read_text())
    for filename, expected in checksums.items():
        if digest(PACKAGE / filename) != expected:
            raise ValueError('包内文件校验失败：' + filename)
    if not conf.is_file():
        raise ValueError('选定容器不存在或缺少配置文件。')
    if args.action == 'status':
        print('目标容器：' + name)
        print('驱动：' + (digest(driver) if driver.exists() else '未准备'))
        print('脚本安装记录：' + ('有，可回退' if state_path.exists() else '无'))
        return
    if args.action == 'launch':
        launcher = bottle / 'drive_c/Program Files (x86)/Netease/MCStudio/MCStudio.exe'
        if not launcher.is_file():
            raise ValueError('容器补丁可提前应用；打开启动器需要先在该容器安装官方启动器。')
        if not driver.exists() or digest(driver) != checksums['payload/winemac.so']:
            raise ValueError('请先安装本包的选定驱动。')
        command = [str(runtime / 'bin/wine'), '--bottle', name,
                   '--workdir', str(bottle / 'drive_c/Program Files (x86)/Netease/MCStudio'),
                   '--debugmsg', '-all', '--cx-app', r'C:\Program Files (x86)\Netease\MCStudio\MCStudio.exe']
        if args.dry_run:
            print('检查通过：将打开选定容器中的官方启动器。')
            return
        with (base / 'embed-script-launch.log').open('ab') as log:
            subprocess.Popen(command, stdout=log, stderr=log, start_new_session=True)
        print('已打开选定启动器。请从启动器进入编辑器。')
        return
    if args.action == 'rollback':
        if not state_path.exists():
            raise ValueError('没有本脚本的安装记录，不能猜测应恢复哪一份文件。')
        state = json.loads(state_path.read_text())
        merged_config = restored_config(conf.read_text(), Path(state['conf']['backup']).read_text(), runtime)
        merged_menu = restored_menu(Path(state['menu']['path']).read_text(), Path(state['menu']['backup']).read_text(), state['menu']) if 'menu' in state else None
        for name in list(state):
            item = state[name]
            if name not in ('conf', 'menu') and digest(Path(item['path'])) != item['installed_sha256']:
                raise ValueError('安装后文件又发生变化，未覆盖：' + name)
        if args.dry_run:
            print('检查通过：可恢复本脚本安装前的配置、快捷方式和驱动。')
            return
        ensure_closed(bottle, runtime)
        for name in list(reversed(state)):
            item = state[name]
            if name in ('conf', 'menu'):
                temp = base / 'restore-config.tmp'
                temp.write_text(merged_config if name == 'conf' else merged_menu)
                atomic_copy(temp, Path(item['path']))
                temp.unlink()
            else:
                atomic_copy(Path(item['backup']), Path(item['path']))
        state_path.rename(state_path.with_name('embed-script-restored-' + uuid.uuid4().hex + '.json'))
        print('已恢复本脚本安装前的状态；原来的实验配置可能仍在，详见说明。')
        return
    if state_path.exists():
        # Re-running after installing MCStudio only connects newly created shortcuts.
        state = json.loads(state_path.read_text())
        merged_original = restored_config(conf.read_text(), Path(state['conf']['backup']).read_text(), runtime)
        for key,item in state.items():
            if key not in ('conf', 'menu') and digest(Path(item['path'])) != item['installed_sha256']:
                raise ValueError('补丁安装后文件发生变化，未覆盖：'+key)
        state['conf']['installed_sha256'] = digest(conf)
        plan = menu_plan(bottle, runtime, state)
        candidates = []
        recorded = {item['path'] for item in state.values()}
        for path in (bottle / 'desktopdata').rglob('*.lnk'):
            if any(word in path.name.lower() for word in ('卸载', 'uninstall')): continue
            try: text = path.read_text()
            except (UnicodeError, OSError): continue
            if text.startswith('#!') and 'MCStudio/' in text and '--start' in text and '/bin/wine' in text:
                if str(path) not in recorded:
                    if path.is_symlink(): raise ValueError('快捷方式指向容器外部，未修改。')
                    candidates.append((path, text))
        if args.dry_run:
            print('检查通过：容器补丁已存在，可连接新安装的启动器快捷方式。')
            return
        ensure_closed(bottle, runtime)
        added = []
        menu_before = Path(plan[0]['path']).read_bytes() if plan else None
        old_menu = dict(state['menu']) if 'menu' in state else None
        menu_backup_before = Path(old_menu['backup']).read_bytes() if old_menu else None
        try:
            original_path = Path(state['conf']['backup'])
            temp = base / 'updated-original-conf.tmp'
            temp.write_text(merged_original)
            atomic_copy(temp, original_path)
            temp.unlink()
            for path, text in candidates:
                quoted = shlex.quote(str(runtime / 'bin/wine'))
                changed, count = re.subn(r'(?m)^exec "[^"\n]+/bin/wine"', lambda _: 'exec ' + quoted, text)
                if count != 1: raise ValueError('无法识别启动器快捷方式，未覆盖。')
                key = 'shortcut-' + uuid.uuid4().hex
                saved = base / key
                shutil.copy2(path, saved)
                added.append((key, path, saved))
                temp = base / (key + '.new')
                temp.write_text(changed)
                temp.chmod(path.stat().st_mode & 0o777)
                atomic_copy(temp, path)
                temp.unlink()
                state[key] = {'path':str(path), 'backup':str(saved), 'installed_sha256':digest(path)}
            commit_menu(plan, state, base)
            temp = state_path.with_suffix('.new.json')
            temp.write_text(json.dumps(state, indent=2)+'\n')
            os.replace(temp, state_path)
        except Exception:
            for _, path, saved in added: atomic_copy(saved, path)
            if plan and menu_before is not None: Path(plan[0]['path']).write_bytes(menu_before)
            if old_menu and menu_backup_before is not None: Path(old_menu['backup']).write_bytes(menu_backup_before)
            raise
        print('容器补丁已应用，官方启动器图标已连接。' if plan or candidates else '容器补丁已应用。启动器后装时再次运行本脚本即可。')
        return
    plan = menu_plan(bottle, runtime, {})
    source = args.runtime_source.expanduser().resolve()
    source_driver = source / 'lib/wine/x86_64-unix/winemac.so'
    # Accept any CrossOver version; this payload still requires its x86_64 layout.
    selected = runtime if runtime.exists() else source
    required = ('bin/wine', 'bin/wineloader', 'lib/wine/x86_64-unix/winemac.so')
    if not all((selected / filename).is_file() for filename in required):
        raise ValueError('运行库不完整或不具备 x86_64 Wine 目录结构，未注入。')
    print('不限制 CrossOver 版本；当前驱动只在 26.3 上验证，其他版本兼容性待验证。')
    subprocess.run(['/usr/bin/codesign', '--verify', '--strict', str(PACKAGE / 'payload/winemac.so')], check=True)
    if args.dry_run:
        print('检查通过：将修改选定容器 ' + name + '，并备份配置、专属驱动及启动器快捷方式。')
        return
    ensure_closed(bottle, runtime)
    base.mkdir(parents=True, exist_ok=True)
    if not runtime.exists():
        # A new destination only. Never remove a partially copied directory.
        subprocess.run(['/bin/cp', '-cR', str(source), str(runtime)], check=True)
    backup = base / ('embed-script-backup-' + uuid.uuid4().hex)
    backup.mkdir()
    state = {}
    targets = [('conf', conf), ('driver', driver)]
    shortcuts = []
    for path in (bottle / 'desktopdata').rglob('*.lnk'):
        if any(word in path.name.lower() for word in ('卸载', 'uninstall')): continue
        try: text = path.read_text()
        except (UnicodeError, OSError): continue
        if text.startswith('#!') and 'MCStudio/' in text and '--start' in text and '/bin/wine' in text:
            if path.is_symlink(): raise ValueError('快捷方式指向容器外部，未修改：' + str(path))
            shortcuts.append((path, text))
    for i, (path, _) in enumerate(shortcuts): targets.append(('shortcut-' + str(i), path))
    for key, path in targets:
        saved = backup / key
        shutil.copy2(path, saved)
        state[key] = {'path': str(path), 'backup': str(saved)}
    try:
        atomic_copy(PACKAGE / 'payload/winemac.so', driver)
        for path, old_text in shortcuts:
            # Keep --bottle and the Windows shortcut path intact.
            quoted = shlex.quote(str(runtime / 'bin/wine'))
            new_text, count = re.subn(r'(?m)^exec "[^"\n]+/bin/wine"', lambda _: 'exec ' + quoted, old_text)
            if count != 1: raise ValueError('无法识别启动器快捷方式，已恢复：' + str(path))
            temp = backup / 'new-shortcut'
            temp.write_text(new_text)
            temp.chmod(path.stat().st_mode & 0o777)
            atomic_copy(temp, path)
        text = conf.read_text()
        for section, key, value in [
            ('Wine', 'LibPath', str(runtime / 'lib')),
            ('Wine', 'BinPath', str(runtime / 'bin')),
            ('EnvironmentVariables', 'MODPC_SHARED_GL', '1'),
            ('EnvironmentVariables', 'CX_GRAPHICS_BACKEND', 'wined3d'),
            ('EnvironmentVariables', 'CX_FWD_COMPAT_GL_CTX', '1'),
            ('EnvironmentVariables', 'LANG', 'zh_CN.UTF-8'),
            ('EnvironmentVariables', 'LC_ALL', 'zh_CN.UTF-8'),
            ('EnvironmentVariables', 'PYTHONIOENCODING', 'utf-8'),
        ]:
            text = setting(text, section, key, value)
        temp = backup / 'new-conf'
        temp.write_text(text)
        atomic_copy(temp, conf)
        commit_menu(plan, state, backup)
        for item in state.values():
            item['installed_sha256'] = digest(Path(item['path']))
        state_path.write_text(json.dumps(state, indent=2) + '\n')
    except Exception:
        for item in state.values():
            atomic_copy(Path(item['backup']), Path(item['path']))
        raise
    print('容器补丁已注入，已连接安装好的官方启动器图标。启动器后装时再运行一次注入即可；移除可恢复原入口。')


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, subprocess.CalledProcessError) as exc:
        print('未完成：' + str(exc), file=sys.stderr)
        sys.exit(1)
